package com.example.afinal;

import android.app.SearchManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.PorterDuff;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.view.View;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Set;

public class SearchResults extends AppCompatActivity {

    //General Properties
    private String[] splittedQuery;
    private RequestQueue queue;
    private  String latitude;
    private  String longitude;
    private  String predictions[];

    //Card 1 Properties
    private  String city;
    private String cityy;
    private TextView TemperatureTextView;
    private TextView SummaryTextView;
    private TextView CityTextView;
    private ImageView IconImageView;

    //Card 2 Properties
    private TextView HumidityTextView;
    private TextView WindSpeedTextView;
    private TextView VisibilityTextView;
    private TextView PressureTextView;

    //For Progress Bar
    private ProgressBar progressBar;
    private CardView cardView;
    private CardView cardView2;
    private TextView textViewProgressBar;


    //Card 3 Properties
    private CardView listCardView;
    private JSONArray date;
    private ListView weeklyListView;
    String[] c3dates;
    int[] c3tempLow;
    int[] c3tempHigh;
    String[] c3icon;

    //Data to send for Detailed View Tab-2
    private  String dvT2Icon;
    private String dvT2Summary;

    //Data to send for Detailed View Tab-1
    private  String dvT1windSpeed;
    private  String dvT1pressure;
    private  String dvT1precipitation;
    private  String dvT1temperature;
    private  String dvT1humidity;
    private  String dvT1visibility;
    private  String dvT1cloudCover;
    private  String dvT1ozone;
    private  String dvT1center;
    private String[] dvT1;

    //Data to send for Detailed View Tab-3
    private ArrayList imageURLs;

    //Floating Action Buttons
    private FloatingActionButton floatingActionButton;
    private FloatingActionButton floatingActionButton2;
    SharedPreferences pref;
    SharedPreferences.Editor editor;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTheme(R.style.DarkTheme);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_results);
        handleIntent(getIntent());

        pref = getApplicationContext().getSharedPreferences("MyPref", 0);
        editor = pref.edit();

        textViewProgressBar=(TextView)findViewById(R.id.textViewProgressBar);
        cardView=(CardView)findViewById(R.id.cardView);
        cardView2=(CardView)findViewById(R.id.cardView2);
        listCardView=(CardView) findViewById(R.id.listCardView);
        weeklyListView=(ListView)findViewById((R.id.weeklyListView));
        progressBar=(ProgressBar)findViewById(R.id.progressBar);
        floatingActionButton=(FloatingActionButton)findViewById(R.id.floatingActionButton);
        floatingActionButton2=(FloatingActionButton)findViewById(R.id.floatingActionButton2);

        textViewProgressBar.setVisibility(View.VISIBLE);
        progressBar.setVisibility(View.VISIBLE);
        cardView.setVisibility(View.INVISIBLE);
        cardView2.setVisibility(View.INVISIBLE);
        weeklyListView.setVisibility(View.INVISIBLE);
        floatingActionButton.setVisibility(View.INVISIBLE);
        floatingActionButton2.setVisibility(View.INVISIBLE);
        listCardView.setVisibility(View.INVISIBLE);

        TemperatureTextView = (TextView) findViewById(R.id.TemperatureTextView);
        SummaryTextView = (TextView) findViewById(R.id.SummaryTextView);
        CityTextView = (TextView) findViewById(R.id.CityTextView);
        IconImageView = (ImageView) findViewById(R.id.IconImageView);

        HumidityTextView = (TextView) findViewById(R.id.HumidityTextView);
        WindSpeedTextView = (TextView) findViewById(R.id.WindSpeedTextView);
        VisibilityTextView = (TextView) findViewById(R.id.VisibilityTextView);
        PressureTextView = (TextView) findViewById(R.id.PressureTextView);

        weeklyListView=(ListView)findViewById(R.id.weeklyListView);
    }

    @Override
    protected void onNewIntent(Intent intent)
    {
        handleIntent(intent);
    }

    private void handleIntent(Intent intent) {


        if (Intent.ACTION_SEARCH.equals(intent.getAction()))
        {
            String query = intent.getStringExtra(SearchManager.QUERY);
            setTitle(query);
            city=query;

            splittedQuery=query.split(", ");

            queue = Volley.newRequestQueue(this);

            if(splittedQuery.length==1)
            {
                geoLocation(splittedQuery[0],splittedQuery[0]);
            }
            else
            {
                geoLocation(splittedQuery[0],splittedQuery[1]);
            }

            cityy=splittedQuery[0];

        }
    }

    private void geoLocation(String a1,String b1)
    {
        String url ="http://hw9luv.us-east-2.elasticbeanstalk.com/geolocation/street="+a1+"&city="+a1+"&state="+b1;
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url,null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try
                        {
                            latitude=response.getString("latitude");
                            longitude=response.getString("longitude");

                            CityTextView.setText(city);
                            darkSkyMethod(latitude,longitude);
                            get8Images(cityy);


                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        }

        );
        queue.add(request);


    }

    private void darkSkyMethod(String a, String b)
    {
        String url ="http://hw9luv.us-east-2.elasticbeanstalk.com/darksky/latitude="+a+"&longitude="+b;
        JsonObjectRequest request2 = new JsonObjectRequest(Request.Method.GET, url,null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {


                            //Card 1
                            JSONObject currently=response.getJSONObject("currently");
                            char tmp = 0x00B0;
                            int temp = currently.getInt("temperature");
                            String temperature=temp+""+tmp+"F";
                            String summary=currently.getString("summary");
                            String icon=currently.getString("icon");
                            TemperatureTextView.setText(temperature);
                            SummaryTextView.setText(summary);


                            if(icon.equals("clear-night"))
                            {
                                IconImageView.setImageResource(R.drawable.weather_night);
                            }
                            else if(icon.equals("rain"))
                            {
                                IconImageView.setImageResource(R.drawable.weather_rainy);
                            }
                            else if(icon.equals("sleet"))
                            {
                                IconImageView.setImageResource(R.drawable.weather_snowy_rainy);
                            }
                            else if(icon.equals("snow"))
                            {
                                IconImageView.setImageResource(R.drawable.weather_snowy);
                            }
                            else if(icon.equals("wind"))
                            {
                                IconImageView.setImageResource(R.drawable.weather_windy_variant);
                            }
                            else if(icon.equals("fog"))
                            {
                                IconImageView.setImageResource(R.drawable.weather_fog);
                            }
                            else if(icon.equals("cloudy"))
                            {
                                IconImageView.setImageResource(R.drawable.weather_cloudy);
                            }
                            else if(icon.equals("partly-cloudy-night"))
                            {
                                IconImageView.setImageResource(R.drawable.weather_night_partly_cloudy);
                            }
                            else if(icon.equals("partly-cloudy-day"))
                            {
                                IconImageView.setImageResource(R.drawable.weather_partly_cloudy);
                            }
                            else
                            {
                                IconImageView.setImageResource(R.drawable.weather_sunny);
                                IconImageView.setColorFilter(getResources().getColor(R.color.yellow), PorterDuff.Mode.SRC_IN );
                            }


                            //Card 2
                            double h=currently.getDouble("humidity");
                            int hu= (int)(h*100);
                            String hum=hu+"%";


                            double w=currently.getDouble("windSpeed");
                            double v=currently.getDouble("visibility");
                            double p=currently.getDouble("pressure");
                            double pp=currently.getDouble("precipIntensity");
                            double o=currently.getDouble("ozone");

                            double cc=currently.getDouble("cloudCover");
                            int ccc= (int)(cc*100);
                            String cCover=ccc+"%";


                            //For Tab1 Detailed View
                            dvT1windSpeed=String.format("%.2f", w)+" mph";
                            dvT1humidity=hum;
                            dvT1visibility=String.format("%.2f", v)+" km";
                            dvT1pressure=String.format("%.2f", p)+" mb";
                            dvT1precipitation=String.format("%.2f", pp)+" mmph";
                            dvT1temperature=temperature;
                            dvT1cloudCover=cCover;
                            dvT1ozone=String.format("%.2f", o)+" DU";
                            dvT2Icon=icon;

                            dvT1=new String[9];
                            dvT1[0]=dvT1windSpeed;
                            dvT1[1]=dvT1pressure;
                            dvT1[2]=dvT1precipitation;
                            dvT1[3]=dvT1temperature;
                            dvT1[4]=dvT2Icon;
                            dvT1[5]=dvT1humidity;
                            dvT1[6]=dvT1visibility;
                            dvT1[7]=dvT1cloudCover;
                            dvT1[8]=dvT1ozone;



                            HumidityTextView.setText(hum);
                            WindSpeedTextView.setText(dvT1windSpeed);
                            VisibilityTextView.setText(dvT1visibility);
                            PressureTextView.setText(dvT1pressure);


                            //Card 3
                            JSONObject daily=response.getJSONObject("daily");
                            dvT2Icon=daily.getString("icon");
                            dvT2Summary=daily.getString("summary");
                            date=daily.getJSONArray("data");

                            c3dates=new String[date.length()];
                            c3tempLow=new int[date.length()];
                            c3tempHigh=new int[date.length()];
                            c3icon=new String[date.length()];

                            for(int i=0;i<date.length();i++)
                            {
                                JSONObject tempp=date.getJSONObject(i);

                                c3dates[i]=tempp.getString("time");
                                c3icon[i]=tempp.getString("icon");
                                c3tempLow[i]=tempp.getInt("temperatureLow");
                                c3tempHigh[i]=tempp.getInt("temperatureHigh");
                            }

                            Card3Adapter card3Adapter=new Card3Adapter(getApplicationContext(),c3dates,c3tempLow,c3tempHigh,c3icon);
                            weeklyListView.setAdapter(card3Adapter);


                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        }

        );
        queue.add(request2);


    }

    private void get8Images(final String c1)
    {
        String param="";
        try
        {
            param= URLEncoder.encode(c1, StandardCharsets.UTF_8.toString());
        } catch (UnsupportedEncodingException e)
        {
            e.printStackTrace();
        }

        String url ="http://hw9luv.us-east-2.elasticbeanstalk.com/imagesearch2/city="+param;
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url,null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {

                            imageURLs=new ArrayList();
                            JSONArray imageItems=response.getJSONArray("items");
                            for(int i=0;i<8;i++)
                            {
                                JSONObject temp=imageItems.getJSONObject(i);
                                imageURLs.add(temp.getString("link"));
                            }
                            textViewProgressBar.setVisibility(View.INVISIBLE);
                            progressBar.setVisibility(View.INVISIBLE);
                            cardView.setVisibility(View.VISIBLE);
                            cardView2.setVisibility(View.VISIBLE);
                            weeklyListView.setVisibility(View.VISIBLE);
                            listCardView.setVisibility(View.VISIBLE);

                            if(pref.getBoolean(city,false))
                            {
                                floatingActionButton2.setVisibility(View.VISIBLE);
                            }
                            else
                            {
                                floatingActionButton.setVisibility(View.VISIBLE);
                            }







                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        }

        );
        queue.add(request);


    }
    public void DetailedView(View view)
    {
        //create a Bundle object
        Bundle extras = new Bundle();
        //Adding key value pairs to this bundle
        //there are quite a lot data types you can store in a bundle
        extras.putString("dvT2Icon",dvT2Icon);
        extras.putString("dvT2Summary",dvT2Summary);

        extras.putIntArray("dvT2TempLow", c3tempLow);
        extras.putIntArray("dvT2TempHigh", c3tempHigh);

        extras.putStringArray("dvT1",dvT1);

        extras.putStringArrayList("imageURLs",imageURLs);

        extras.putString("city",city);

        //create and initialize an intent
        Intent intent = new Intent(this, DetailedView.class);

        //attach the bundle to the Intent object
        intent.putExtras(extras);

        startActivity(intent);
    }
    public void changeImage(View view)
    {
        editor.putBoolean(city,true);
        editor.commit();


        floatingActionButton.setVisibility(View.INVISIBLE);
        Toast.makeText(getApplicationContext(),city+" was added to favorites",Toast.LENGTH_SHORT).show();
        floatingActionButton2.setVisibility(View.VISIBLE);
    }
    public void changeImage2(View view)
    {
        editor.putBoolean(city,false);
        editor.commit();

        floatingActionButton2.setVisibility(View.INVISIBLE);
        Toast.makeText(getApplicationContext(),city+" was removed from favorites",Toast.LENGTH_SHORT).show();
        floatingActionButton.setVisibility(View.VISIBLE);
    }

}
