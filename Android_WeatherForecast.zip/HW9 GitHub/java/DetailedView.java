package com.example.afinal;

import android.app.SearchManager;
import android.arch.lifecycle.ViewModelProviders;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.graphics.PorterDuff;
import android.net.Uri;
import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;


import com.example.afinal.ui.main.SectionsPagerAdapter;


public class DetailedView extends AppCompatActivity {

    private String city="";
    private String temper="";
    private DataTransfer dataTransfer;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTheme(R.style.DarkTheme);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detailed_view);
        SectionsPagerAdapter sectionsPagerAdapter = new SectionsPagerAdapter(this, getSupportFragmentManager());
        ViewPager viewPager = findViewById(R.id.view_pager);
        viewPager.setAdapter(sectionsPagerAdapter);
        TabLayout tabs = findViewById(R.id.tabs);
        tabs.setupWithViewPager(viewPager);

        tabs.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab)
            {
                tab.getIcon().setColorFilter(getResources().getColor(R.color.white), PorterDuff.Mode.SRC_IN );
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab)
            {
                tab.getIcon().setColorFilter(getResources().getColor(R.color.metaColor), PorterDuff.Mode.SRC_IN );
            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });

        //get the intent in the target activity
        Intent intent = getIntent();
        //get the attached bundle from the intent
        Bundle extras = intent.getExtras();
        city=extras.getString("city");
        setTitle(city);

        String message1=extras.getString("dvT2Summary");
        String message2=extras.getString("dvT2Icon");

        String[] temp=new String[2];
        temp[0]=message1;
        temp[1]=message2;

        dataTransfer= ViewModelProviders.of(this).get(DataTransfer.class);
        dataTransfer.setTab2Card(temp);

        dataTransfer.setTempLow(extras.getIntArray("dvT2TempLow"));
        dataTransfer.setTempHigh(extras.getIntArray("dvT2TempHigh"));

        dataTransfer.setTab1Data(extras.getStringArray("dvT1"));

        temper=extras.getStringArray("dvT1")[3];

        dataTransfer.setImageURLs(extras.getStringArrayList("imageURLs"));




        tabs.getTabAt(0).setIcon(R.drawable.calendar_today);
        tabs.getTabAt(1).setIcon(R.drawable.trending_up);
        tabs.getTabAt(2).setIcon(R.drawable.google_photos);


    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.detailed_view, menu);

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        String twitterUrl="https://twitter.com/intent/tweet?text=Check%20Out%20"+city+"’s%20Weather!%20It%20is%20"+temper+"!&hashtags=CSCI571WeatherSearch";
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            case R.id.twitter:
                if(item.getItemId()==R.id.twitter)
                {
                    Intent intent=new Intent(Intent.ACTION_VIEW, Uri.parse(twitterUrl));
                    startActivity(intent);
                }
                else
                {
                    Intent intent=new Intent(this,MainActivity.class);
                    startActivity(intent);
                }

                return true;

            default:
                return super.onOptionsItemSelected(item);
        }




    }




}