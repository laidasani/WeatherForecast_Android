package com.example.afinal;

import android.arch.lifecycle.ViewModel;

import java.util.ArrayList;


public class DataTransfer extends ViewModel
{
    private int[] tempLow;
    private int[] tempHigh;
    private String[] Tab2Card=new String[2];
    private String[] Tab1Data=new String[9];
    private ArrayList imageURLs=new ArrayList();

    public void setTab2Card(String[] Tab2Card)
    {
        this.Tab2Card = Tab2Card;
    }
    public String[] getTab2Card()
    {
        return Tab2Card;
    }

    public int[] getTempLow()
    {
        return tempLow;
    }

    public void setTempLow(int[] tempLow)
    {
        this.tempLow = tempLow;
    }

    public int[] getTempHigh()
    {
        return tempHigh;
    }

    public void setTempHigh(int[] tempHigh)
    {
        this.tempHigh = tempHigh;
    }

    public String[] getTab1Data()
    {
        return Tab1Data;
    }

    public void setTab1Data(String[] tab1Data)
    {
        Tab1Data = tab1Data;
    }

    public ArrayList getImageURLs() {
        return imageURLs;
    }

    public void setImageURLs(ArrayList imageURLs) {
        this.imageURLs = imageURLs;
    }
}
