package com.example.afinal;

import android.arch.lifecycle.ViewModelProviders;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import java.util.ArrayList;

public class Tab3 extends Fragment {
    private ImageView imageView;
    RecyclerView recyclerView;
    GridLayoutManager gridLayoutManager;
    private DataTransfer dataTransfer;
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        dataTransfer= ViewModelProviders.of((FragmentActivity) getActivity()).get(DataTransfer.class);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
    {
        View rootView=inflater.inflate(R.layout.tab3,container,false);
        imageView = (ImageView) rootView.findViewById(R.id.imageViewGrid);
        recyclerView = (RecyclerView) rootView.findViewById(R.id.recyclerView);
        gridLayoutManager = new GridLayoutManager(getContext(), 1);
        recyclerView.setLayoutManager(gridLayoutManager);

        ArrayList imageUrlList = dataTransfer.getImageURLs();
        ImageDataAdapter dataAdapter = new ImageDataAdapter(getContext(), imageUrlList);
        recyclerView.setAdapter(dataAdapter);


        return rootView;
    }

}
