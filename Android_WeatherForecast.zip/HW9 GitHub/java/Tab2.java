package com.example.afinal;

import android.arch.lifecycle.ViewModelProviders;
import android.content.Context;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.content.ContextCompat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.Description;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.interfaces.datasets.ILineDataSet;

import java.util.ArrayList;
import java.util.List;

public class Tab2 extends Fragment {

    LineChart mLineChart;

    private DataTransfer dataTransfer;
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        dataTransfer= ViewModelProviders.of((FragmentActivity) getActivity()).get(DataTransfer.class);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
    {
        View rootView=inflater.inflate(R.layout.tab2,container,false);

        EditText DVTab2EditText=(EditText) rootView.findViewById(R.id.DVTab2EditView);
        String[] temp=dataTransfer.getTab2Card();
        DVTab2EditText.setText(temp[0]);

        ImageView DVTab2ImageView=(ImageView) rootView.findViewById(R.id.DVTab2ImageView);

        String icon=temp[1];

        if(icon.equals("clear-night"))
        {
            DVTab2ImageView.setImageResource(R.drawable.weather_night);
        }
        else if(icon.equals("rain"))
        {
            DVTab2ImageView.setImageResource(R.drawable.weather_rainy);
        }
        else if(icon.equals("sleet"))
        {
            DVTab2ImageView.setImageResource(R.drawable.weather_snowy_rainy);
        }
        else if(icon.equals("snow"))
        {
            DVTab2ImageView.setImageResource(R.drawable.weather_snowy);
        }
        else if(icon.equals("wind"))
        {
            DVTab2ImageView.setImageResource(R.drawable.weather_windy_variant);
        }
        else if(icon.equals("fog"))
        {
            DVTab2ImageView.setImageResource(R.drawable.weather_fog);
        }
        else if(icon.equals("cloudy"))
        {
            DVTab2ImageView.setImageResource(R.drawable.weather_cloudy);
        }
        else if(icon.equals("partly-cloudy-night"))
        {
            DVTab2ImageView.setImageResource(R.drawable.weather_night_partly_cloudy);
        }
        else if(icon.equals("partly-cloudy-day"))
        {
            DVTab2ImageView.setImageResource(R.drawable.weather_partly_cloudy);
        }
        else
        {
            DVTab2ImageView.setImageResource(R.drawable.weather_sunny);
            DVTab2ImageView.setColorFilter(getResources().getColor(R.color.yellow), PorterDuff.Mode.SRC_IN );
        }

        int lowTemp[]=dataTransfer.getTempLow();
        int highTemp[]=dataTransfer.getTempHigh();

        mLineChart=(LineChart)rootView.findViewById(R.id.lineChart1);

        List<Entry> valsComp1 = new ArrayList<Entry>();
        List<Entry> valsComp2 = new ArrayList<Entry>();

        for(int i=0;i<lowTemp.length;i++)
        {
            Entry c1e1 = new Entry(i, highTemp[i]);
            valsComp1.add(c1e1);

            Entry c2e1 = new Entry(i, lowTemp[i]);
            valsComp2.add(c2e1);
        }


        Context context=getContext();
        LineDataSet setComp2 = new LineDataSet(valsComp2, "Minimum Temperature");
        setComp2.setAxisDependency(YAxis.AxisDependency.LEFT);
        LineDataSet setComp1 = new LineDataSet(valsComp1, "Maximum Temperature");
        setComp1.setAxisDependency(YAxis.AxisDependency.LEFT);


        setComp1.setColors(new int[] {R.color.graph2}, context);
        setComp1.setCircleColor(Color.WHITE);
        setComp1.setCircleHoleColor(Color.WHITE);
        setComp1.setDrawValues(false);



        setComp2.setColors(new int[] {R.color.graph1}, context);
        setComp2.setCircleColor(Color.WHITE);
        setComp2.setCircleHoleColor(Color.WHITE);
        setComp2.setDrawValues(false);


        List<ILineDataSet> dataSets = new ArrayList<>();
        dataSets.add(setComp2);
        dataSets.add(setComp1);
        LineData data = new LineData(dataSets);

        int color = ContextCompat.getColor(context, R.color.metaColor);

        XAxis xAxis = mLineChart.getXAxis();
        xAxis.setGranularity(1f);
        xAxis.setTextColor(color);
        xAxis.setDrawGridLines(false);



        YAxis leftAxis = mLineChart.getAxisLeft();
        YAxis rightAxis = mLineChart.getAxisRight();
        leftAxis.setGridColor(color);
        leftAxis.setTextColor(color);
        rightAxis.setGridColor(color);
        rightAxis.setTextColor(color);

        mLineChart.getLegend().setTextColor(Color.WHITE);
        mLineChart.getLegend().setTextSize(16);

        Description description=new Description();
        description.setText("");
        mLineChart.setDescription(description);

        mLineChart.setData(data);
        mLineChart.invalidate();

        return rootView;
    }

}
