package com.example.afinal;

import android.arch.lifecycle.ViewModelProviders;
import android.graphics.PorterDuff;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;


public class Tab1 extends Fragment {

    private DataTransfer dataTransfer;
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        dataTransfer= ViewModelProviders.of((FragmentActivity) getActivity()).get(DataTransfer.class);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
    {
        View rootView=inflater.inflate(R.layout.tab1,container,false);
        String[] tab1Data=dataTransfer.getTab1Data();

        TextView textView1=(TextView)rootView.findViewById(R.id.Tab1No1);
        textView1.setText(tab1Data[0]);

        TextView textView3=(TextView)rootView.findViewById(R.id.Tab1No2);
        textView3.setText(tab1Data[1]);

        TextView textView5=(TextView)rootView.findViewById(R.id.Tab1No3);
        textView5.setText(tab1Data[2]);

        TextView textView8=(TextView)rootView.findViewById(R.id.Tab1No4);
        textView8.setText(tab1Data[3]);


        TextView textView7=(TextView)rootView.findViewById(R.id.Tab1No5);
        String icon=tab1Data[4];
        ImageView IconImageView=(ImageView)rootView.findViewById(R.id.imageView12);

        if(icon.equals("clear-night"))
        {
            IconImageView.setImageResource(R.drawable.weather_night);
            textView7.setText("clear night");
        }
        else if(icon.equals("rain"))
        {
            IconImageView.setImageResource(R.drawable.weather_rainy);
            textView7.setText("rain");
        }
        else if(icon.equals("sleet"))
        {
            IconImageView.setImageResource(R.drawable.weather_snowy_rainy);
            textView7.setText("sleet");
        }
        else if(icon.equals("snow"))
        {
            IconImageView.setImageResource(R.drawable.weather_snowy);
            textView7.setText("snow");
        }
        else if(icon.equals("wind"))
        {
            IconImageView.setImageResource(R.drawable.weather_windy_variant);
            textView7.setText("wind");
        }
        else if(icon.equals("fog"))
        {
            IconImageView.setImageResource(R.drawable.weather_fog);
            textView7.setText("fog");
        }
        else if(icon.equals("cloudy"))
        {
            IconImageView.setImageResource(R.drawable.weather_cloudy);
            textView7.setText("cloudy");
        }
        else if(icon.equals("partly-cloudy-night"))
        {
            IconImageView.setImageResource(R.drawable.weather_night_partly_cloudy);
            textView7.setText("cloudy night");
        }
        else if(icon.equals("partly-cloudy-day"))
        {
            IconImageView.setImageResource(R.drawable.weather_partly_cloudy);
            textView7.setText("cloudy day");
        }
        else
        {
            IconImageView.setImageResource(R.drawable.weather_sunny);
            IconImageView.setColorFilter(getResources().getColor(R.color.yellow), PorterDuff.Mode.SRC_IN );
            textView7.setText(icon);
        }

        TextView textView10=(TextView)rootView.findViewById(R.id.Tab1No6);
        textView10.setText(tab1Data[5]);

        TextView textView12=(TextView)rootView.findViewById(R.id.Tab1No7);
        textView12.setText(tab1Data[6]);

        TextView textView14=(TextView)rootView.findViewById(R.id.Tab1No8);
        textView14.setText(tab1Data[7]);

        TextView textView20=(TextView)rootView.findViewById(R.id.Tab1No9);
        textView20.setText(tab1Data[8]);


        return rootView;
    }





}
