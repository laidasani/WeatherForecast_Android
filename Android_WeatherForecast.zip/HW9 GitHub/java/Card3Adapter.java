package com.example.afinal;

import android.content.Context;
import android.support.v4.app.ActivityCompat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Card3Adapter extends BaseAdapter
{
    LayoutInflater mInflater;
    String[] c3dates;
    int[] c3tempLow;
    int[] c3tempHigh;
    String[] c3icon;
    Context ctext;

    public Card3Adapter(Context c, String[] d, int[] l, int[] h, String[] i)
    {
        mInflater=(LayoutInflater)c.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        c3dates=d;
        c3tempLow=l;
        c3tempHigh=h;
        c3icon=i;
        ctext=c;
    }

    @Override
    public int getCount() {
        return c3dates.length;
    }

    @Override
    public Object getItem(int position) {
        return c3dates[position];
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent)
    {
        View v=mInflater.inflate(R.layout.weekly_list_helper,null);
        TextView c3DateTextView= (TextView)v.findViewById(R.id.c3DateTextView);
        TextView c3TempLowTextView= (TextView)v.findViewById(R.id.c3TempLowTextView);
        TextView c3TempHighTextView= (TextView)v.findViewById(R.id.c3TempHighTextView);
        ImageView c3ImageView= (ImageView)v.findViewById(R.id.c3ImageView);


        long epoch = Long.parseLong( c3dates[position] );
        Date expiry = new Date( epoch * 1000 );
        DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
        c3DateTextView.setText(dateFormat.format(expiry));

        c3TempLowTextView.setText(c3tempLow[position]+"");
        c3TempHighTextView.setText(c3tempHigh[position]+"");


        if(c3icon[position].equals("clear-night"))
        {
            c3ImageView.setImageResource(R.drawable.weather_night);
        }
        else if(c3icon[position].equals("rain"))
        {
            c3ImageView.setImageResource(R.drawable.weather_rainy);
        }
        else if(c3icon[position].equals("sleet"))
        {
            c3ImageView.setImageResource(R.drawable.weather_snowy_rainy);
        }
        else if(c3icon[position].equals("snow"))
        {
            c3ImageView.setImageResource(R.drawable.weather_snowy);
        }
        else if(c3icon[position].equals("wind"))
        {
            c3ImageView.setImageResource(R.drawable.weather_windy_variant);
        }
        else if(c3icon[position].equals("fog"))
        {
            c3ImageView.setImageResource(R.drawable.weather_fog);
        }
        else if(c3icon[position].equals("cloudy"))
        {
            c3ImageView.setImageResource(R.drawable.weather_cloudy);
        }
        else if(c3icon[position].equals("partly-cloudy-night"))
        {
            c3ImageView.setImageResource(R.drawable.weather_night_partly_cloudy);
        }
        else if(c3icon[position].equals("partly-cloudy-day"))
        {
            c3ImageView.setImageResource(R.drawable.weather_partly_cloudy);
        }
        else
        {
            c3ImageView.setImageResource(R.drawable.weather_sunny);
            c3ImageView.setColorFilter(ActivityCompat.getColor(ctext, R.color.yellow));
        }

        return v;
    }
}
